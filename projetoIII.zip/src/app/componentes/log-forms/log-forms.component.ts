import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-log-forms',
  templateUrl: './log-forms.component.html',
  styleUrls: ['./log-forms.component.scss']
})
export class LogFormsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
