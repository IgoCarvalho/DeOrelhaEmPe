import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tipography',
  templateUrl: './tipography.component.html',
  styleUrls: ['./tipography.component.scss']
})
export class TipographyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
