import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogFormsComponent } from './componentes/log-forms/log-forms.component';
import { LoginFormComponent } from './componentes/log-forms/login-form/login-form.component';
import { ButtonsComponent } from './componentes/buttons/buttons.component';
import { RegisterFormComponent } from './componentes/log-forms/register-form/register-form.component';
import { ComponentesComponent } from './componentes/componentes.component';

const routes: Routes = [
  {path: '', component: ComponentesComponent},

  {path: 'user', component: LogFormsComponent, children: [
    {path: 'login', component: LoginFormComponent},
    {path: 'cad', component: RegisterFormComponent}
  ] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
